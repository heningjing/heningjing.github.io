// Responsive Timeline
// Timeline for a personal project
// Github: http://github.com/itbruno/responsive-timeline